# 📦 DELIVERY NOTES · MortgageCalculator

**交付包名稱**: `mortgage-calculator-delivery.zip`
**交付日期**: 2026-05-30
**Git commit**: `d6ce5b2` (🚀 Sprint B · Tool 1/3 · MortgageCalculator · finance Profile B)
**Branch**: `main`
**Sprint**: B · finance Profile B 第二批 · 第 1 個工具(共 3 個)

---

## 1. 交付清單 (3 個必交檔案 + 4 個附贈證據鏈)

### 必交 (MANDATORY)

| # | 檔案 | 狀態 |
|---|---|---|
| 1 | `client/src/tools/finance/MortgageCalculator/index.tsx` (580 行) | ✅ |
| 2 | `shared/toolsConfig.ts` (含 mortgage-calculator entry + named export) | ✅ |
| 3 | `DELIVERY-NOTES.md` (本檔) | ✅ |

### 附贈 (RECOMMENDED · 證據鏈完整)

| # | 檔案 | 用途 |
|---|---|---|
| A | `client/src/pages/ToolPage.tsx` | 第 2 個三向註冊點 (lazy import line 25) |
| B | `client/src/pages/Home.tsx` | 第 3 個三向註冊點 (featuredTools entry · `Home as HomeIcon` import) |
| C | `ops/specs/mortgage-calculator.md` | Phase 1 公式凍結規格 |
| D | `ops/journals/mortgage-trial-2026-05.md` | 9 階段製作日誌(含 Node 預演 3 案例) |

---

## 2. QC 守門員報告 (4 項全綠)

### 2.1 17-Layer Anatomy

```
$ python3 scripts/qc_layer_audit.py
✅ [B] client/src/tools/finance/MortgageCalculator/index.tsx  17/17 layers
```
**結果**: 17/17 ✅

### 2.2 Visual Layout

```
$ python3 scripts/qc_layout_audit.py
✅ client/src/tools/finance/MortgageCalculator/index.tsx  6/6 layouts
```
**結果**: 6/6 ✅ (L1 1.05/0.95 · L5 0.9/1.1 · L6 0.95/1.05 · L9 1/0.9 · L10 1/0.8 · L14 1/0.9)

### 2.3 Route Audit

```
$ python3 scripts/qc_route_audit.py
🟢 finance/mortgage-calculator    ✅ ToolPage · ✅ toolsConfig · ✅ Home
   ↳ client/src/tools/finance/MortgageCalculator/index.tsx
============================================================
Summary: 9 tool(s) scanned · 0 critical · 0 soft warning
============================================================
✅ ALL ROUTE REGISTRATIONS GREEN.
```
**結果**: 0 critical · 0 soft warning ✅

### 2.4 TypeScript

```
$ cd client && npx tsc --noEmit
(空輸出 = 0 errors)
```
**結果**: 0 errors ✅

### 2.5 Triple QC 統一輸出

```
$ python3 scripts/qc_all.py
... (所有 9 工具全綠) ...
================================================================
  ✅ ALL QC CHECKS PASSED
```
**結果**: ALL CHECKS PASSED ✅

---

## 3. 三向註冊證據 (路徑 + 行號可追溯)

### 3.1 ToolPage.tsx (lazy 路由註冊)

```tsx
// client/src/pages/ToolPage.tsx · line 25
"finance/mortgage-calculator": lazy(() => import("@/tools/finance/MortgageCalculator")),
```

### 3.2 toolsConfig.ts (tools[] metadata)

```ts
// shared/toolsConfig.ts · line 167-181
{
  id: "mortgage-calculator",
  name: "房貸試算機",
  category: "finance",
  path: "/tools/finance/mortgage-calculator",
  icon: "Home",
  description: "輸入房價 / 頭期 / 利率 / 年期 / 房屋稅 / 保險,結合本利攤還(等額本息)+ 房屋稅 + 保險 + 頭期款的完整房貸計算器,30 年購屋總成本一次看清楚;含 5/10/15/20/25/30 年六段對照。",
  isPremium: false,
  showAds: true,
  rateLimit: 30,
  isNew: true,
  isFeatured: true,
  status: "GOLD",
  seoArticles: [],
},
```

### 3.3 toolsConfig.ts (named export)

```ts
// shared/toolsConfig.ts · line 222
export const mortgageCalculator = { id: "mortgage-calculator", category: "finance", name: "Mortgage Calculator", path: "/tools/finance/mortgage-calculator" };
```

### 3.4 Home.tsx (featuredTools)

```tsx
// client/src/pages/Home.tsx · line 162
{ name: { zh: "房貸試算機", en: "Mortgage Calculator" }, category: { zh: "財務", en: "finance" }, description: { zh: "輸入房價 / 頭期 / 利率 / 年期 / 房屋稅 / 保險,結合本利攤還 + 房屋稅 + 保險的完整月付,30 年購屋總成本一次看清楚;含 5/10/15/20/25/30 年六段對照。", en: "Home price + down payment + rate + term + tax + insurance → see your true monthly payment and 30-year total cost; includes 5/10/15/20/25/30-year comparison." }, href: "/tools/finance/mortgage-calculator", icon: HomeIcon },
```

### 3.5 Home.tsx (lucide icon import)

```tsx
// client/src/pages/Home.tsx · line 17
Home as HomeIcon,
```
(避免與 `Home` 元件命名衝突)

---

## 4. 工具規格摘要

| 項目 | 值 |
|---|---|
| 工具 ID | `mortgage-calculator` |
| 路由 | `/tools/finance/mortgage-calculator` |
| 類別 | `finance` |
| Profile | `B` (Calculator-YMYL) |
| 主公式 | `M = P · [r(1+r)^N] / [(1+r)^N − 1] + 月稅 + 月保險` |
| 6 段年期 | 5 / 10 / 15 / 20 / 25 / 30 yr |
| L6 三大主數值 | `primaryValue=monthlyTotal` · `maintenanceTarget=totalInterest` · `actionTarget=totalCost` |
| Hero 漸層 | `emerald-500 → teal-500 → cyan-600` |
| AdSlot 命名 | `mortgage-hero-ad` / `mortgage-mid-ad` / `mortgage-bottom-ad` |
| FAQ 題數 | 6 題雙語 (zh + en) |
| 預設值 | 30M 房 / 20% 頭期 / 2.1% / 30 yr / 30K 稅 / 8K 保險 → 月付 ~93,080 |
| i18n | `useLanguage()` from `@/contexts/LanguageContext` (全域同步) |

---

## 5. 教訓記錄(Phase 6 修復清單)

製作過程遇到 3 類 TypeScript 錯誤,已全數修復:

1. **AdSenseWrapper / AdSlot 規格不符**
   - 誤用: `<AdSenseWrapper id="..."><AdSlot slotId="..." /></AdSenseWrapper>`
   - 正確: `<AdSenseWrapper showAds={true} adSlot="..." adFormat="horizontal" className="my-2" />` (self-closing)

2. **matrix block 型別窄化失敗**
   - 誤用: `"monthlyTotal" in row` 動態檢查 + 條件展開
   - 正確: 採 LoanCalculator 黃金母體模式,`fallback merge` 預先補 0

3. **FAQ Record cast 型別衝突**
   - 誤用: `(t as Record<string, string>)[qKey]` (因 ui 含 `standards: [...]` 陣列)
   - 正確: `(t as unknown as Record<string, string>)[qKey]` 雙重轉型

**回饋至 SOP**: 已在 journal 紀錄,後續工具直接照黃金母體 Loan/Compound 模式即可避免。

---

## 6. 交付前最終檢核清單 (8 項自審)

| # | 項目 | 通過 |
|---|---|---|
| 1 | i18n 使用 `useLanguage()` 而非 `useState<Lang>(getBrowserLang())` | ✅ |
| 2 | L6 三大主數值 `data-l6` 標記齊全 | ✅ |
| 3 | 6 段年期 (5/10/15/20/25/30) 完整對照表 | ✅ |
| 4 | 17 Layer 全到位 (含 L7 Result Intelligence + L17 Trust) | ✅ |
| 5 | 6 Layout 比例正確 (L1/L5/L6/L9-Upper/L10-Lower/L14) | ✅ |
| 6 | Triple binding 全綠 (ToolPage ∩ toolsConfig ∩ Home) | ✅ |
| 7 | PascalCase 命名 (`MortgageCalculator` 首字母大寫) | ✅ |
| 8 | Hero 漸層差異化 (emerald→teal→cyan,與 8 既有工具不撞色) | ✅ |
| 9 | TypeScript 0 errors | ✅ |

---

## 7. 工具總清單情境

### 本 ZIP 鎖定的工具

只有 1 個: **MortgageCalculator** (Sprint B Tool 1/3)

### Workspace 還有的 Sprint B 待製工具

- ⏳ Tool 2/3: **CreditCardPayoffCalculator** (信用卡反推 · clone 自 SavingsGoal)
- ⏳ Tool 3/3: **DebtToIncomeCalculator** (負債所得比 · clone 自 Bmi)

兩工具的規格凍結書已在 `ops/specs/` 完成,待 Victor 接收 Tool 1/3 後依序量產。

### Workspace 既有 8 個工具 (Sprint A 已上線)

- health: Bmi · Bmr · Tdee
- finance: Loan · CompoundInterest · Retirement · Cagr · SavingsGoal

加上本次 MortgageCalculator,共 **9 個工具** 在 main branch HEAD。

---

## 8. 交付聲明

本人 SuperNinja 在此聲明:

1. ✅ 本 ZIP 含 SOP-delivery-standard.md 第 2 節要求的 3 個必交檔案
2. ✅ 本 ZIP 含第 3 節要求的 4 個附贈檔案 (證據鏈完整)
3. ✅ 本 DELIVERY-NOTES.md 含第 4 節要求的 9 大區段
4. ✅ 本 ZIP 內所有 QC stdout 為實際執行結果,非估算
5. ✅ Triple QC 全綠,無 critical / soft warning
6. ✅ 已 commit 至 `main` branch (hash `d6ce5b2`),Railway 將自動部署

如有任一項不實,願承擔退件重做的責任。

---

## 9. 部署驗證指令 (Victor 可重跑)

### 9.1 拉取最新版本

```bash
cd /Users/victor/Sites/Tool-Matrix-Repo
git pull origin main
git log --oneline -3
# 應看到: d6ce5b2 🚀 Sprint B · Tool 1/3 · MortgageCalculator
```

### 9.2 三 QC 重跑驗證

```bash
cd my-tools-matrix
python3 scripts/qc_layer_audit.py    # 應顯示: ✅ [B] MortgageCalculator 17/17 layers
python3 scripts/qc_layout_audit.py   # 應顯示: ✅ MortgageCalculator 6/6 layouts
python3 scripts/qc_route_audit.py    # 應顯示: 🟢 finance/mortgage-calculator ✅ ToolPage · ✅ toolsConfig · ✅ Home
python3 scripts/qc_all.py            # 應顯示: ✅ ALL QC CHECKS PASSED
```

### 9.3 TypeScript 重跑驗證

```bash
cd my-tools-matrix/client && npx tsc --noEmit
# 應顯示: (空輸出 = 0 errors)
```

### 9.4 Production 上線檢查 (~60s 後)

```bash
curl -I https://my-tools-matrix-production.up.railway.app/tools/finance/mortgage-calculator
# 應回 HTTP 200 OK
```

或瀏覽器直接訪問:
**https://my-tools-matrix-production.up.railway.app/tools/finance/mortgage-calculator**

---

**狀態**: ✅ Tool 1/3 完成,等待 Victor 驗收。
**下一步**: 收到 Victor ✅ 後,開始 Tool 2/3 CreditCardPayoffCalculator 全文重寫(目前僅有規格凍結書 + clone 母體)。
